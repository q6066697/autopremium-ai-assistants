# 🚗 Нейроассистенты для автосалона «АвтоПремиум»

> Учебный проект по промпт-инжинирингу — три нейроассистента для автоматизации ключевых бизнес-функций компании по продаже автомобилей.

---

## 📋 О проекте

Набор системных промптов и баз знаний для трёх ИИ-ассистентов автосалона. Каждый ассистент закрывает отдельное направление бизнеса и готов к импорту в ChatGPT (GPTs), Claude Projects или любое no-code решение.

| Ассистент | Направление | Ключевые функции |
|---|---|---|
| 🔵 АвтоКонсультант | Продажи | Подбор авто, тест-драйв, работа с возражениями |
| 🟢 КадровыйПомощник | HR | Вакансии, скрининг кандидатов, запись на интервью |
| 🟠 СервисПомощник | Постпродажа | Гарантия, запись в сервис, обработка жалоб |

---

## 📁 Структура репозитория

```
autopremium-assistants/
│
├── README.md                        # Этот файл
│
├── prompts/
│   ├── 01_sales_assistant.md        # Системный промпт: АвтоКонсультант
│   ├── 02_hr_assistant.md           # Системный промпт: КадровыйПомощник
│   └── 03_aftersales_assistant.md   # Системный промпт: СервисПомощник
│
├── knowledge_base/
│   ├── faq_sales.md                 # FAQ — Продажи
│   ├── faq_hr.md                    # FAQ — HR
│   └── faq_aftersales.md            # FAQ — Постпродажное обслуживание
│
├── scenarios/
│   ├── scenario_sales.md            # Типовой диалог: клиент → продажи
│   ├── scenario_hr.md               # Типовой диалог: кандидат → HR
│   └── scenario_aftersales.md       # Типовой диалог: владелец → сервис
│
└── docs/
    └── neuro_assistants_autopremium.docx   # Полный документ (Word)
```

---

## 🚀 Быстрый старт

### Импорт в ChatGPT (GPTs)
1. Перейти на [chat.openai.com](https://chat.openai.com) → My GPTs → Create
2. В поле **Instructions** вставить содержимое нужного файла из папки `prompts/`
3. Сохранить и протестировать

### Импорт в Claude Projects
1. Открыть [claude.ai](https://claude.ai) → Projects → New Project
2. В **Project instructions** вставить системный промпт
3. В **Project Files** загрузить соответствующий FAQ из папки `knowledge_base/`

### Импорт в no-code (n8n / Make / Botpress)
1. Вставить системный промпт в системный узел LLM-блока
2. FAQ добавить как Knowledge Base или дополнительный контекст
3. Настроить триггер (Telegram webhook, форма на сайте и т.д.)

---

## 🛠️ Технологии и инструменты

![Prompt Engineering](https://img.shields.io/badge/Prompt%20Engineering-blue?style=flat-square)
![OpenAI GPT](https://img.shields.io/badge/OpenAI-GPT--4o-412991?style=flat-square&logo=openai)
![Claude](https://img.shields.io/badge/Anthropic-Claude-orange?style=flat-square)
![No-Code](https://img.shields.io/badge/No--Code-Ready-green?style=flat-square)

---

## 📌 Особенности проекта

- **Специфика отдела** — каждый промпт учитывает реальные задачи конкретного подразделения
- **Ограничения** — прописаны явно, чтобы исключить галлюцинации и выход за рамки роли
- **Сценарии** — типовые диалоги для тестирования и демонстрации
- **Готовность к масштабированию** — промпты легко адаптируются под любой автосалон

---

## ⚠️ Дисклеймер

Все имена, контакты, адреса и показатели в проекте являются **тестовыми и вымышленными**. Проект создан в учебных целях.

---

## 👤 Автор

Проект выполнен в рамках курса по промпт-инжинирингу.

[![LinkedIn](https://img.shields.io/badge/LinkedIn-Connect-0077B5?style=flat-square&logo=linkedin)](https://linkedin.com)
[![GitHub](https://img.shields.io/badge/GitHub-Follow-181717?style=flat-square&logo=github)](https://github.com)
